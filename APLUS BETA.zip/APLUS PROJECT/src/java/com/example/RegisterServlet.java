package com.example;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegisterServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(RegisterServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String code = request.getParameter("code");

        // Define the correct secret code
        String secretCode = "0113";

        try {
            if (code.equals(secretCode)) {
                // Hash the password
                String hashedPassword = hashPassword(password);

                // Register the new user in the database
                if (registerNewUser(username, hashedPassword, code)) {
                    response.sendRedirect("login.jsp");
                } else {
                    // Registration failed (e.g. database issue)
                    request.setAttribute("errorMessage", "Registration failed. Please try again.");
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
            } else {
                // Secret code is incorrect
                request.setAttribute("errorMessage", "Incorrect secret code.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        } catch (NoSuchAlgorithmException e) {
            LOGGER.log(Level.SEVERE, "Password hashing failed", e);
            request.setAttribute("errorMessage", "Internal server error. Please try again later.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    // Register the user in the database
    private boolean registerNewUser(String username, String hashedPassword, String code) {
        String dbUrl = "jdbc:derby://localhost:1527/APlusVentures";
        String dbUser = "APP";
        String dbPassword = "app";

        String insertSQL = "INSERT INTO USERS (USERNAME, PASSWORDHASH, CODE) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             PreparedStatement stmt = conn.prepareStatement(insertSQL)) {

            stmt.setString(1, username);
            stmt.setString(2, hashedPassword);
            stmt.setString(3, code);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database operation failed", e);
            return false;
        }
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(password.getBytes());
        byte[] byteData = md.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : byteData) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
