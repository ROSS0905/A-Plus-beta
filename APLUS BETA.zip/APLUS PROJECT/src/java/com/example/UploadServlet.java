package com.example;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import com.opencsv.CSVWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {
    private static final String UPLOAD_DIRECTORY = "C:\\path\\to\\uploads\\"; // Update this path
    private static final String CSV_OUTPUT_PATH = "C:\\path\\to\\uploads\\output.csv"; // Update this path

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Part filePart = request.getPart("file");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        File pdfFile = new File(UPLOAD_DIRECTORY + fileName);

        try (InputStream fileContent = filePart.getInputStream()) {
            Files.copy(fileContent, pdfFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            response.getWriter().write("Error saving file: " + e.getMessage());
            return;
        }

        // Extract information from the PDF
        String[] extractedInfo = extractSpecificInfoFromPDF(pdfFile.getAbsolutePath());

        if (extractedInfo != null) {
            // Write information to the CSV file
            writeInfoToCSV(CSV_OUTPUT_PATH, extractedInfo);
            response.getWriter().write("PDF processed successfully.");
        } else {
            response.getWriter().write("Error extracting information from PDF.");
        }
    }

    private String[] extractSpecificInfoFromPDF(String filePath) {
    String businessName = "";
    String ownerName = "";
    String icNumber = "";
    String birthDate = "";
    String race = "";
    String gender = "";
    String registrationNumber = "";
    String expiryDate = "";
    String address = "";
    String businessType = "";

    try (PDDocument document = PDDocument.load(new File(filePath))) {
        if (document.isEncrypted()) {
            System.err.println("The PDF is encrypted and cannot be processed.");
            return null;
        }

        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(document);

        // Extract using updated regular expressions
        businessName = extractMatch(text, "NAMA PERNIAGAAN\\s*:\\s*([A-Za-z0-9 &,'-]+)(?=\\s*NO PENDAFTARAN)");
        ownerName = extractMatch(text, "NAMA\\s*:\\s*([A-Za-z0-9 &,'-]+)(?=\\s*ALAMAT KEDIAMAN)");
        icNumber = extractMatch(text, "NO K\\/P \\(BARU\\)\\s*:\\s*(\\d{12})");
        birthDate = extractMatch(text, "TARIKH LAHIR\\s*:\\s*(\\d{2}-\\d{2}-\\d{4})");
        race = extractMatch(text, "BANGSA\\s*:\\s*([\\w]+)");
        gender = extractMatch(text, "JANTINA\\s*:\\s*([\\w]+)");
        registrationNumber = extractMatch(text, "NO PENDAFTARAN\\s*:\\s*([\\d\\w/-]+)");
        expiryDate = extractMatch(text, "TARIKH LUPUT PENDAFTARAN\\s*:\\s*(\\d{2}-\\d{2}-\\d{4})");
        address = extractMatch(text, "ALAMAT UTAMA PERNIAGAAN\\s*:\\s*([A-Za-z0-9 &,'-,\\n]+)(?=\\s*BENTUK PERNIAGAAN)");
        businessType = extractMatch(text, "JENIS PERNIAGAAN\\s*:\\s*([A-Za-z0-9 &,'-]+)");

    } catch (IOException e) {
        System.err.println("An error occurred while processing the PDF file:");
        e.printStackTrace();
    }

    return new String[]{businessName, ownerName, icNumber, birthDate, race, gender, registrationNumber, expiryDate, address, businessType};
}


private String extractMatch(String text, String pattern) {
    Matcher matcher = Pattern.compile(pattern).matcher(text);
    return matcher.find() ? matcher.group(1).trim() : "";
}


    private void writeInfoToCSV(String csvFilePath, String[] extractedInfo) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(csvFilePath, true))) {
            File file = new File(csvFilePath);
            if (!file.exists() || file.length() == 0) {
                String[] header = {"Business Name", "Owner Name", "IC Number", "Birth Date", "Race", "Gender", "Registration Number", "Expiry Date", "Business Address", "Business Type"};
                writer.writeNext(header);
            }
            writer.writeNext(extractedInfo);
        } catch (IOException e) {
            System.err.println("An error occurred while writing to the CSV file:");
            e.printStackTrace();
        }
    }
}