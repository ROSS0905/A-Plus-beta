package com.example;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FeedbackServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("NAME");
        String email = request.getParameter("EMAIL");
        String message = request.getParameter("FB");

        if (submitFeedback(name, email, message)) {
            response.sendRedirect("feedback.jsp?success=Feedback submitted successfully");
        } else {
            response.sendRedirect("feedback.jsp?error=Failed to submit feedback");
        }
    }

    private boolean submitFeedback(String name, String email, String message) {
        String dbUrl = "jdbc:derby://localhost:1527/MetroParkDB";
        String dbUser = "APP";
        String dbPassword = "app";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO FEEDBACK (NAME, EMAIL, FB) VALUES (?, ?, ?)")) {

            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, message);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
